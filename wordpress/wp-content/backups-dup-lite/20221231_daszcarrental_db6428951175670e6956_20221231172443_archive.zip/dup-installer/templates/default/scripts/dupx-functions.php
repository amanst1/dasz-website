<?php

/**
 *
 * @package templates/default
 *
 */

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

dupxTplRender('scripts/modules/page-components');
dupxTplRender('scripts/modules/ajax-functions');
dupxTplRender('scripts/modules/progress-bar');
dupxTplRender('scripts/modules/params-module');
dupxTplRender('scripts/modules/system-validation-module');
dupxTplRender('scripts/modules/extraction-module');
dupxTplRender('scripts/modules/top-page-messages');
dupxTplRender('scripts/modules/package-deploy');
dupxTplRender('scripts/modules/db-test');
dupxTplRender('scripts/modules/db-charset');
dupxTplRender('scripts/modules/db-install');
dupxTplRender('scripts/modules/site-replace-and-update');
dupxTplRender('scripts/modules/final-tests');
dupxTplRender('scripts/modules/confirm-dialog');
